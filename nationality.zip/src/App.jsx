
import './App.css'

import FetchNationality from "./fetchNationality";

function App() {

  return (
    <>
      <div>
      <h2>Nationality Prediction App</h2>
      <FetchNationality />
      </div>
    </>
  )
}

export default App

/*---------------------------------------------------------*/
